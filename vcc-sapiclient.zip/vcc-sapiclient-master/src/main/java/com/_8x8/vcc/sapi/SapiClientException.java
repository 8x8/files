/*
 * Copyright (c) 2019. by 8x8. Inc.
 *   _____      _____
 *  |  _  |    |  _  |
 *   \ V /__  __\ V /   ___ ___  _ __ ___
 *   / _ \\ \/ // _ \  / __/ _ \| '_ ` _ \
 *  | |_| |>  <| |_| || (_| (_) | | | | | |
 *  \_____/_/\_\_____(_)___\___/|_| |_| |_|
 *
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information
 *  of 8x8 Inc. ("Confidential Information").  You
 *  shall not disclose such Confidential Information and shall use
 *  it only in accordance with the terms of the license agreement
 *  you entered into with 8x8 Inc.
 *
 */
package com._8x8.vcc.sapi;

/**
 * A VCC SAPI client exception
 */
public class SapiClientException extends Exception {

    /**
     * Handy way to create exceptions
     *
     * @param message Message text
     * @param values  Array of placement values
     */
    SapiClientException(String message, Object... values) {
        super(String.format(message, values));
    }
}
